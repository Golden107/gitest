# 關於 <青春有你2>
## <青春有你2> 是什麼?
![圖片](https://s.yimg.com/ny/api/res/1.2/pc2ytRpyZmfZGNcwKWlHEQ--~A/YXBwaWQ9aGlnaGxhbmRlcjtzbT0xO3c9NTAwO2g9MzUw/https://media-mbst-pub-ue1.s3.amazonaws.com/creatr-uploaded-images/2020-04/cf519700-7b12-11ea-bff6-089b9060ced2)



<青春有你2> 代表 **中國的選秀節目**
一個 html 的頁面範例：
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
                <title>青春有你2</title>
    </head>
    <body>
    <h1>Hello World</h1>
    </body>
    </html>

    是中國愛奇藝推出的偶像女團競演養成類真人秀節目。
本季節目改為女生選秀。
節目賽制是從各家經紀公司或練習生公司選出109位參賽，
在4個多月中進行封閉式的訓練及錄制，
最終由全民票選出9人組成全新偶像團體出道。
本季節目以「多遠都可以到達」為主題，
由蔡徐坤擔任青春製作人代表（主持人），
Lisa擔任舞蹈導師，
陳嘉樺擔任音樂導師，
Jony J擔任說唱導師，
林宥嘉擔任X導師。


## 參加者介紹

| 姓名    |     出生地   | 經紀公司    |
|--------|--------------|------------|
|  符佳  |      遼寧    |   一綜星船   |
|  王清  |      山東    |   大王娛樂   |
|  張鈺  |      北京    |   大王娛樂   |
|  姚依凡 |      陝西   |   天加一     |
|  周梓倩 |      上海   |   天加一     |
|  韓東   |      湖北   |   少城時代   |
|  許馨文 |      湖南   |   少城時代   |
|  黃小芸 |      廣西   |   少城時代   |
| 未書羽  |      江西   |   少城時代   |

共多資訊都在：https://zh.wikipedia.org/wiki/青春有你_(第二季)